﻿namespace BusTicketSystem.Models.Enums
{
    public enum Status
    {
        Departed = 1, Arrived = 2, Delayed = 3, Cancelled = 4
    }
}
