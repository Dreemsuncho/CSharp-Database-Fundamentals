﻿namespace BusTicketSystem.Models.Abstracts
{
    public abstract class EntityBase
    {
        public int Id { get; set; }
    }
}
