﻿namespace BusTicketSystem.Data
{
    internal static class SourceConfig
    {
        internal static string _connectionString = "Data Source=.;Initial Catalog=BusTicketDb;Integrated Security=True";
    }
}
