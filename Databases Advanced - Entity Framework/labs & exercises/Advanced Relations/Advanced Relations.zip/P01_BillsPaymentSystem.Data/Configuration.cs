﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_BillsPaymentSystem.Data
{
    public static class Configuration
    {
        public static readonly string connectionString = "Data Source=.;Initial Catalog=BillsPaymentSystem;Integrated Security=True";
    }
}
