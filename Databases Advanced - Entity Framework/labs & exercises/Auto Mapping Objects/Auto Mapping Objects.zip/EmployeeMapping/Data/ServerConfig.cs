﻿namespace EmployeeMapping.Data
{
    static class ServerConfig
    {
        public static readonly string connectionString = "Data Source=.;Initial Catalog=EmployeeDTO;Integrated Security=True";
    }
}
